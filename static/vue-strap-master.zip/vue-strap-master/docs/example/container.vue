<template>
  <div class="container bs-docs-container">
    <div class="row"><slot></slot></div>
  </div>
</template>
