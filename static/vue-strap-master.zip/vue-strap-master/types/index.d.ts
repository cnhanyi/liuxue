// Simply make TS happy
declare module 'vue-strap';